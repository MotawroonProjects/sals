package com.creativeshare.sals.Activities_Fragments.Home.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.creativeshare.sals.Activities_Fragments.Home.Fragments.Fragment_Home;
import com.creativeshare.sals.Activities_Fragments.Home.Fragments.Fragment_Shipment;
import com.creativeshare.sals.Activities_Fragments.Registration.Activity.Register_Activity;
import com.creativeshare.sals.Language.Language;
import com.creativeshare.sals.R;

import java.util.Locale;

import io.paperdb.Paper;

public class Home_Activity extends AppCompatActivity {
    private FragmentManager fragmentManager;
    private Fragment_Home fragment_home;
    private Fragment_Shipment fragment_shipment;
    private int fragment_count = 0;
    private String current_lang;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(Language.updateResources(newBase, Language.getLanguage(newBase)));

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Paper.init(this);
        current_lang = Paper.book().read("lang", Locale.getDefault().getLanguage());
        fragmentManager = this.getSupportFragmentManager();
        setContentView(R.layout.activity_home);
        if (savedInstanceState == null) {
            DisplayFragmentHome();
            DisplayFragmentShipment();
        }

    }




    public void DisplayFragmentHome() {

        fragment_count += 1;

        if (fragment_home == null) {
            fragment_home = Fragment_Home.newInstance();
        }

        if (fragment_home.isAdded()) {
            fragmentManager.beginTransaction().show(fragment_home).commit();
        } else {
            fragmentManager.beginTransaction().add(R.id.fragment_app_container, fragment_home, "fragment_home").addToBackStack("fragment_home").commit();
        }

    }
  public void DisplayFragmentShipment() {

      if (fragment_shipment == null) {
          fragment_shipment = Fragment_Shipment.newInstance();
      }

      if (fragment_shipment.isAdded()) {
          fragmentManager.beginTransaction().show(fragment_shipment).commit();
      } else {
          fragmentManager.beginTransaction().add(R.id.fragment_main_child, fragment_shipment, "fragment_shipment").addToBackStack("fragment_shipment").commit();
      }
    }

}

