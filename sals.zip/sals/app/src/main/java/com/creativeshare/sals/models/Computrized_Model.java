package com.creativeshare.sals.models;

public class Computrized_Model {
    static String city_From;
    static String City_to;
   static String price;
    static String day_number;
    static String time;
   static String type;
static String quantity;
static String weight;

    public static String getQuantity() {
        return quantity;
    }

    public static void setQuantity(String quantity) {
        Computrized_Model.quantity = quantity;
    }

    public static String getWeight() {
        return weight;
    }

    public static void setWeight(String weight) {
        Computrized_Model.weight = weight;
    }

    public static String getCity_From() {
        return city_From;
    }

    public static void setCity_From(String city_From) {
        Computrized_Model.city_From = city_From;
    }

    public static String getCity_to() {
        return City_to;
    }

    public static void setCity_to(String city_to) {
        City_to = city_to;
    }

    public static String getPrice() {
        return price;
    }

    public static void setPrice(String price) {
        Computrized_Model.price = price;
    }

    public static String getDay_number() {
        return day_number;
    }

    public static void setDay_number(String day_number) {
        Computrized_Model.day_number = day_number;
    }

    public static String getTime() {
        return time;
    }

    public static void setTime(String time) {
        Computrized_Model.time = time;
    }

    public static String getType() {
        return type;
    }

    public static void setType(String type) {
        Computrized_Model.type = type;
    }
}
