package com.creativeshare.sals.tags;

public class Tags {

    public static final String base_url = "http://salisexpress.com/";
    public static final String IMAGE_URL = base_url+"uploads/images/";
    public static final String IMAGE_URL_Detials = base_url+"uploads/images/thumbs/";

    public static final String session_login = "login";
    public static final String session_logout = "logout";





}
